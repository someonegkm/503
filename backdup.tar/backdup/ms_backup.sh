#!/usr/bin/env bash
# ms_backup.sh (TRULY FINAL)
# - TYPE=1: 일반 MySQL 서버
# - TYPE=2: Docker 컨테이너 MySQL
# 기능:
#   backup : conf의 SCHEMAS 전체 백업(.sql.gz)
#   restore: 지정/오늘 폴더에서 각 스키마 "정확히 일치"하는 최신 파일(.sql|.sql.gz) 복원
# 특징:
#   - .sql/.sql.gz 자동 처리
#   - TYPE=2 복원은 컨테이너 내부 소켓 접속 + --database 강제 (수동과 동일)
#   - FK/UNIQUE/바이너리로그 임시 OFF로 충돌 완화
#   - stdout+stderr 전부 로그 저장
#   - 백업 후 간단 검증 보고

set -euo pipefail

CONF_FILE="./metadb_backup.conf"
ACTION="${1:-}"
TARGET="${2:-}"

if [[ ! -f "$CONF_FILE" ]]; then
  echo "환경설정 파일을 찾을 수 없습니다: $CONF_FILE"
  exit 1
fi
# shellcheck disable=SC1090
source "$CONF_FILE"

# ===== 기본값 =====
TODAY="$(date +%Y%m%d)"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP_DIR="${BACKUP_BASE_DIR:-./$TODAY}"
mkdir -p "$BACKUP_DIR"

DEFAULT_CHARSET="${DEFAULT_CHARSET:-utf8mb4}"
DOCKER_DB_HOST="${DOCKER_DB_HOST:-127.0.0.1}" # 백업 시 TCP
DOCKER_DB_PORT="${DOCKER_DB_PORT:-3306}"

: "${SCHEMAS:?SCHEMAS 배열을 metadb_backup.conf에 설정하세요. 예) SCHEMAS=(\"querypie\" \"querypie_log\" \"querypie_snapshot\") }"

# ===== 유틸 =====
check_bins() {
  command -v gzip >/dev/null 2>&1 || { echo "gzip 이 필요합니다."; exit 1; }
  if [[ "$TYPE" == "1" ]]; then
    command -v mysqldump >/dev/null 2>&1 || { echo "mysqldump 가 필요합니다."; exit 1; }
    command -v mysql >/dev/null 2>&1 || { echo "mysql 가 필요합니다."; exit 1; }
  elif [[ "$TYPE" == "2" ]]; then
    command -v docker >/dev/null 2>&1 || { echo "docker 가 필요합니다."; exit 1; }
  else
    echo "잘못된 TYPE 값: $TYPE"
    exit 1
  fi
}

# ===== 백업 =====
do_backup() {
  check_bins
  echo "백업 시작 -> 저장경로: $BACKUP_DIR"
  for schema in "${SCHEMAS[@]}"; do
    OUT_FILE="${BACKUP_DIR}/${schema}_${STAMP}.sql.gz"
    echo "  - ${schema} 덤프 생성: ${OUT_FILE}"
    if [[ "$TYPE" == "1" ]]; then
      mysqldump \
        -h"$DB_HOST" -P"$DB_PORT" \
        -u"$DB_USER" -p"$DB_PASS" \
        --default-character-set="${DEFAULT_CHARSET}" \
        --single-transaction --routines --triggers --events \
        --set-gtid-purged=OFF \
        --databases "$schema" \
        | gzip > "$OUT_FILE"
    else
      docker exec "$DOCKER_CONTAINER" mysqldump \
        -h"${DOCKER_DB_HOST}" -P"${DOCKER_DB_PORT}" \
        -u"$DB_USER" -p"$DB_PASS" \
        --default-character-set="${DEFAULT_CHARSET}" \
        --single-transaction --routines --triggers --events \
        --set-gtid-purged=OFF \
        --databases "$schema" \
        | gzip > "$OUT_FILE"
    fi
  done
  echo "백업 완료. 자동 검증 수행 중..."
  verify_backups "$BACKUP_DIR" "$STAMP"
}

verify_backups() {
  local dir="$1" stamp="$2"
  local ok=0 fail=0
  echo "---- 백업 검증 리포트 ($dir / $stamp) ----"
  for schema in "${SCHEMAS[@]}"; do
    local f="${dir}/${schema}_${stamp}.sql.gz"
    if [[ ! -f "$f" ]]; then
      echo "  [WARN] $schema: 파일 없음 -> $f"
      ((fail++)) || true
      continue
    fi
    if gzip -t "$f" 2>/dev/null; then
      local header_count table_defs size
      header_count="$(zcat "$f" | grep -c '^-- MySQL dump' || true)"
      table_defs="$(zcat "$f" | egrep -c '^(CREATE TABLE|CREATE VIEW)' || true)"
      size="$(du -h "$f" | awk '{print $1}')"
      printf "  [OK]   %-18s gzip:OK, header:%d, defs:%d, size:%s\n" \
        "$schema" "$header_count" "$table_defs" "$size"
      ((ok++)) || true
    else
      echo "  [FAIL] $schema: gzip 무결성 오류 -> $f"
      ((fail++)) || true
    fi
  done
  echo "-----------------------------------------"
  echo "검증 결과: OK=$ok, FAIL=$fail"
  [[ $fail -eq 0 ]] || { echo "일부 백업에 문제가 있습니다. 로그 확인 필요."; exit 2; }
}

# ===== 복원 =====
resolve_restore_dir() {
  if [[ -n "$TARGET" ]]; then
    if [[ -d "$TARGET" ]]; then
      echo "$TARGET"
    elif [[ "$TARGET" =~ ^[0-9]{8}$ && -d "./$TARGET" ]]; then
      echo "./$TARGET"
    else
      echo "복원 대상 디렉토리를 찾을 수 없습니다: $TARGET"
      exit 1
    fi
  else
    [[ -d "./$TODAY" ]] && echo "./$TODAY" || { echo "복원 디렉토리를 지정하세요."; exit 1; }
  fi
}

# 스키마명 정확히 일치하는 최신 파일 선택(.sql.gz 우선)
select_latest_file() {
  local dir="$1" schema="$2"

  # .sql.gz 정규식 매칭
  local f
  f="$(find "$dir" -maxdepth 1 -type f -regextype posix-extended \
      -regex "$dir/${schema}_[0-9]{8}(_[0-9]{6})?\.sql\.gz" \
      | sort | tail -n 1 || true)"

  if [[ -z "$f" ]]; then
    # .sql 정규식 매칭
    f="$(find "$dir" -maxdepth 1 -type f -regextype posix-extended \
        -regex "$dir/${schema}_[0-9]{8}(_[0-9]{6})?\.sql" \
        | sort | tail -n 1 || true)"
  fi

  echo "$f"
}

restore_one() {
  local schema="$1" file="$2" logf="$3"
  echo "  - ${schema} 복원: ${file}"

  # .sql.gz / .sql 자동 처리
  local READ_CMD="cat"
  [[ "$file" == *.gz ]] && READ_CMD="gunzip -c"

  set +e
  if [[ "$TYPE" == "1" ]]; then
    {
      echo "SET FOREIGN_KEY_CHECKS=0; SET UNIQUE_CHECKS=0; SET sql_log_bin=0;";
      $READ_CMD "$file"
      echo "SET FOREIGN_KEY_CHECKS=1; SET UNIQUE_CHECKS=1; SET sql_log_bin=1;";
    } | mysql \
          -h"$DB_HOST" -P"$DB_PORT" \
          -u"$DB_USER" -p"$DB_PASS" \
          --database="$schema" \
          --default-character-set="${DEFAULT_CHARSET}" \
          --show-warnings --verbose 1>"$logf" 2>&1
    rc=$?
  else
    {
      echo "SET FOREIGN_KEY_CHECKS=0; SET UNIQUE_CHECKS=0; SET sql_log_bin=0;";
      $READ_CMD "$file"
      echo "SET FOREIGN_KEY_CHECKS=1; SET UNIQUE_CHECKS=1; SET sql_log_bin=1;";
    } | docker exec -i "$DOCKER_CONTAINER" mysql \
          -u"$DB_USER" -p"$DB_PASS" \
          --database="$schema" \
          --default-character-set="${DEFAULT_CHARSET}" \
          --show-warnings --verbose 1>"$logf" 2>&1
    rc=$?
  fi
  set -e

  if [[ $rc -ne 0 ]]; then
    echo "    [FAIL] ${schema} 복원 실패. 로그: $logf"
    return $rc
  fi
  echo "    [OK]   ${schema} 복원 완료. 로그: $logf"
  return 0
}

post_verify_rows() {
  local schema="$1"
  local q="
SELECT IFNULL(SUM(TABLE_ROWS),0) AS approx_rows
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_SCHEMA='${schema}';
"
  if [[ "$TYPE" == "1" ]]; then
    mysql -N -s \
      -h"$DB_HOST" -P"$DB_PORT" \
      -u"$DB_USER" -p"$DB_PASS" \
      -e "$q" || echo "N/A"
  else
    docker exec -i "$DOCKER_CONTAINER" mysql -N -s \
      -u"$DB_USER" -p"$DB_PASS" \
      -e "$q" || echo "N/A"
  fi
}

do_restore() {
  check_bins
  local DIR
  DIR="$(resolve_restore_dir)"
  echo "복원 시작 <- 소스경로: $DIR"

  for schema in "${SCHEMAS[@]}"; do
    local FILE LOGF
    FILE="$(select_latest_file "$DIR" "$schema")"
    if [[ -z "$FILE" ]]; then
      echo "  - [WARN] ${schema} 백업 파일을 찾지 못했습니다. (${DIR}/${schema}_YYYYMMDD(.HHMMSS).sql[.gz])"
      continue
    fi

    LOGF="${DIR}/restore_${schema}_${STAMP}.log"
    if restore_one "$schema" "$FILE" "$LOGF"; then
      local ROWS
      ROWS="$(post_verify_rows "$schema" || true)"
      echo "    -> ${schema} 대략 총 레코드 수: ${ROWS}"
    fi
  done
  echo "복원 완료."
}

usage() {
  cat <<USAGE
사용법:
  백업:   $0 backup
  복원:   $0 restore [YYYYMMDD|백업디렉토리]

비고:
- SCHEMAS: metadb_backup.conf에서 스키마 배열로 지정합니다.
- TYPE=2(도커) 복원: 컨테이너 내부 소켓 접속 + --database 강제(수동과 동일).
- .sql/.sql.gz 자동 처리, 파일 선택은 스키마명 "정확 일치"로 안전하게 수행.
- 문자셋: DEFAULT_CHARSET(기본 utf8mb4).
- 백업 후 자동 검증, 복원 로그는 restore_<schema>_<timestamp>.log 저장.
USAGE
}

case "$ACTION" in
  backup)  do_backup ;;
  restore) do_restore ;;
  ""|--help|-h) usage ;;
  *) echo "알 수 없는 동작: $ACTION"; usage; exit 1 ;;
esac

