# MySQL 백업 & 복원 스크립트 사용 가이드

## 1. 개요
이 스크립트는 MySQL/MariaDB 데이터베이스를 **압축 백업(.sql.gz)** 하고  
필요 시 **정확한 스키마별 복원**을 지원합니다.

- **TYPE=1** → 일반 DBMS (직접 TCP 접속)
- **TYPE=2** → Docker 컨테이너 내부 MySQL (컨테이너명 지정)

`.sql`과 `.sql.gz` 모두 자동 처리하며,  
복원 시 **스키마명 정확 일치**하는 최신 파일만 사용합니다.

---

## 2. 환경 설정 (`metadb_backup.conf`)

```bash
# 접속 환경 타입 (1=일반 DB, 2=Docker 컨테이너)
TYPE=2

# Docker 컨테이너 이름 (TYPE=2일 때 필수)
DOCKER_CONTAINER="querypie-mysql-1"

# 일반 DBMS 접속 정보 (TYPE=1일 때 필수)
DB_HOST="127.0.0.1"
DB_PORT="3306"
DB_USER="root"
DB_PASS="Querypie1!"

# 백업/복원할 스키마 목록
SCHEMAS=("querypie" "querypie_log" "querypie_snapshot")

# (선택) 백업 저장 경로 (기본: ./YYYYMMDD)
# BACKUP_BASE_DIR="/var/backups/mysql"

# (선택) 기본 문자셋
# DEFAULT_CHARSET="utf8mb4"

